(()=>{
 let busy=false,catalog=null,pickerBatch='',pickerQuery='',currentTaskId=null,currentHost=null,lastPath='',dismissed=false,boundTaskId=null,boundTaskTitle='';
 const UI_KEY='desk-channels-panel-v1';
 const readUI=()=>{try{return JSON.parse(localStorage.getItem(UI_KEY)||'{}');}catch{return {};}};
 function setBusy(value){busy=value;currentHost?.shadowRoot?.querySelectorAll('[data-picker]').forEach(el=>el.disabled=value);if(!value)currentHost?.refreshPicker?.();}
 async function loadCatalog(){const r=await chrome.runtime.sendMessage({type:'state'});if(!r?.ok)throw Error(r?.error||'分发台未返回内容');catalog=r.result;return catalog;}
 const taskOrder=t=>Number.isInteger(t.sequence)?t.sequence:999999;
 function orderedTasks(){return (catalog?.tasks||[]).filter(t=>!['published','canceled','running','queued'].includes(t.status)&&!t.title.includes('分发流程测试')&&(!pickerBatch||t.batch_id===pickerBatch)&&(!pickerQuery||[t.title,t.account,taskOrder(t)===999999?'':String(taskOrder(t))].join(' ').toLowerCase().includes(pickerQuery.toLowerCase()))).sort((a,b)=>taskOrder(a)-taskOrder(b)||a.title.localeCompare(b.title,'zh-CN'));}
 function selectTask(t){if(busy)throw Error('当前操作尚未完成，请等待后再换条');if(!t)return;currentTaskId=t.id;panel(t,(catalog?.assets||[]).filter(a=>t.asset_ids.includes(a.id)||a.id===t.cover_id));}

 const field=async(kind,op,extra={})=>{const r=await chrome.runtime.sendMessage({type:'field',kind,op,...extra});if(!r.ok)throw Error(r.error);return r.result;};
 const scan=async()=>{const r=await chrome.runtime.sendMessage({type:'frames'});if(!r.ok)throw Error(r.error);return r.result;};
 const preflight=async(manual)=>{
  const report=await scan();
  for(const kind of [...(manual?[]:['video']),'body','title']){
   const count=report.reduce((n,f)=>n+(f.counts?.[kind]||0),0);
   if(count!==1)throw Error('检查未通过：'+kind+'候选='+count+'，扫描frame='+report.length+'；请导出结构诊断');
  }
  return report;
 };
 async function file(asset){const r=await chrome.runtime.sendMessage({type:'asset',id:asset.id});if(!r.ok)throw Error(r.error);const bytes=Uint8Array.from(atob(r.result.base64),c=>c.charCodeAt(0));return new File([bytes],asset.name,{type:asset.mime||r.result.mime});}
 function upload(input,f){const dt=new DataTransfer();dt.items.add(f);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));}
 function panel(task=null,assets=[],autoStart=false){
 const selected=!!task?.id;task=task||{title:'',body:'',tags:'',account:'',asset_ids:[],options:{}};
 if(busy)throw Error('当前操作尚未完成');
 document.querySelector('#desk-channels-assistant')?.remove();
 const host=document.createElement('div');host.id='desk-channels-assistant';currentHost=host;host.style.cssText='position:fixed;right:16px;top:90px;width:auto;z-index:2147483647';
 const root=host.attachShadow({mode:'open'});root.innerHTML='<style>:host{font:14px/1.6 system-ui;color:#284039}section{box-sizing:border-box;resize:both;min-width:280px;width:340px;height:650px;min-height:160px;max-width:90vw;max-height:80vh;background:white;border:2px solid #284039;padding:16px;border-radius:12px;box-shadow:0 4px 24px #0003;max-height:75vh;overflow:auto}button{padding:10px;margin:5px 0;width:100%;cursor:pointer}img{max-height:180px;max-width:100%;object-fit:contain}pre{white-space:pre-wrap;font:13px/1.5 system-ui}small{color:#65786b}</style><section><div id="panel-bar" style="display:flex;align-items:center;justify-content:space-between;cursor:move;touch-action:none;user-select:none"><strong>分发台 0.6.1 · 拖动移动</strong><button id="smaller" style="width:auto;padding:4px">−</button><button id="larger" style="width:auto;padding:4px">＋</button><button id="collapse" style="width:auto;padding:4px">收起</button></div><div id="panel-body"><button id="diagnose">检查页面并下载结构诊断</button><p id="title"></p><img id="cover" hidden><pre id="copy"></pre><button id="fill">加载到当前页面：视频、文案与封面</button><button id="fill-only">我已手动上传视频，仅填写文案</button><button id="sync-title">重新同步短标题</button><button id="upload-cover">重试上传封面</button><button id="save" disabled>核对完成，保存草稿一次</button><button id="close">关闭辅助面板</button><pre id="status"></pre><small>公开发布由你点击平台“发表”。本扩展不点击该按钮，不自动回填成功状态。</small></div></section>';
 root.querySelector('#title').textContent=task.title+' · '+task.account;root.querySelector('#copy').textContent=task.body+'\n'+task.tags;const copyBox=root.querySelector('#copy');const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent='查看完整文案';copyBox.before(details);details.append(summary,copyBox);const plan=document.createElement('p');plan.textContent='合集：'+(task.options?.collection||'未指定')+' · 标注：个人观点 · 时间：'+((task.assistScheduled||task.scheduled)?new Date(task.assistScheduled||task.scheduled).toLocaleString('zh-CN'):'未安排');details.before(plan);
 root.querySelector('#close').onclick=()=>{if(!busy){dismissed=true;host.remove();}};
 const style=document.createElement('style');style.textContent='*{box-sizing:border-box}button,input,select{font:inherit}button{border:1px solid #d5dfd9;border-radius:5px;background:#f7faf8}button:disabled{opacity:.48;cursor:default}input,select{width:100%;padding:8px;border:1px solid #cbd8d0;border-radius:5px;background:white;margin:4px 0 8px}button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid #548570;outline-offset:2px}label{display:block;font-size:12px}#picker-controls{border-bottom:1px solid #e3eae5;padding:12px 0;margin-bottom:12px}.picker-row{display:flex;gap:7px}.picker-row button{flex:1;padding:7px 2px;font-size:12px}#fill{background:#284b40;color:white}#page-observation{background:#f0f5f1;padding:8px;border-radius:5px;font-size:12px}#picker-status,#status{overflow-wrap:anywhere}section{max-width:calc(100vw - 16px);max-height:calc(100vh - 16px)}[hidden]{display:none!important}';root.append(style);
 const picker=document.createElement('div');picker.id='picker-controls';picker.innerHTML='<label>内容批次<select id="picker-batch" data-picker aria-label="内容批次"><option value="">所有批次</option></select></label><label>搜索内容<input id="picker-search" data-picker placeholder="标题、序号或账号" aria-label="搜索内容"></label><label>选择本次内容<select id="picker-task" data-picker aria-label="选择本次内容"><option value="">请选择内容</option></select></label><div class="picker-row"><button id="picker-prev" data-picker>上一条</button><button id="picker-next" data-picker>下一条</button><button id="picker-refresh" data-picker>刷新内容</button></div><small id="picker-status">正在连接本机分发台…</small>';
 root.querySelector('#panel-body').prepend(picker);
 const observation=document.createElement('div');observation.id='page-observation';observation.setAttribute('aria-live','polite');observation.textContent=boundTaskId?'页面仍关联：'+boundTaskTitle+'。当前选择仅供预览，加载后才更新关联。':'页面尚未关联内容。选择只预览，加载后才关联本次操作。';picker.after(observation);
 root.querySelector('#close').setAttribute('data-picker','');
 root.querySelector('#status').setAttribute('aria-live','polite');
 const preview=document.createElement('div');preview.id='selected-preview';preview.hidden=!selected;observation.after(preview);
 for(const el of [root.querySelector('#title'),root.querySelector('#cover'),plan,details,root.querySelector('#fill'),root.querySelector('#fill-only'),root.querySelector('#sync-title'),root.querySelector('#upload-cover'),root.querySelector('#save')])preview.append(el);
 const repairs=document.createElement('details'),repairSummary=document.createElement('summary');repairSummary.textContent='修复与页面诊断';repairs.append(repairSummary,root.querySelector('#sync-title'),root.querySelector('#upload-cover'),root.querySelector('#diagnose'));root.querySelector('#save').before(repairs);
 const choices=document.createElement('div');choices.innerHTML='<label style="display:flex;gap:8px;align-items:center"><input id="declare-original" type="checkbox" checked style="width:auto;margin:0">本条声明原创</label><small>仅适用于你拥有原创权利的内容；平台条款由你阅读处理。</small><button id="apply-options">应用原创与合集选项</button>';repairs.before(choices);
 async function applyOptions(){const notes=[];if(root.querySelector('#declare-original').checked){const r=await field('original','select');if(r.checked)notes.push('声明原创已回读为勾选');}if(task.options?.collection){const r=await field('collection','select',{value:task.options.collection});if(r.selected)notes.push('合集已回读：'+r.value);}else notes.push('任务未指定合集，请在分发台设置后刷新内容');return notes;}
 root.querySelector('#apply-options').onclick=async()=>{if(busy||!selected)return;if(boundTaskId!==task.id){status.textContent='请先加载本条内容，或用仅填写入口确认页面视频属于本条。';return;}setBusy(true);try{status.textContent=(await applyOptions()).join('；');}catch(e){status.textContent='选项待核对：'+e.message;}finally{setBusy(false);}};
 function renderPicker(){const batches=root.querySelector('#picker-batch');batches.replaceChildren(new Option('所有批次',''),...(catalog?.batches||[]).map(b=>new Option(b.name,b.id)));batches.value=pickerBatch;const tasks=orderedTasks(),sel=root.querySelector('#picker-task');sel.replaceChildren(new Option('请选择内容',''),...tasks.map(t=>new Option((taskOrder(t)===999999?'':'第 '+String(taskOrder(t)).padStart(2,'0')+' 条 · ')+t.title+' · '+t.account,t.id)));sel.value=tasks.some(t=>t.id===currentTaskId)?currentTaskId:'';root.querySelector('#picker-search').value=pickerQuery;root.querySelector('#picker-status').textContent=tasks.length+' 条匹配。'+(selected&&!tasks.some(t=>t.id===task.id)?'当前预览不在此筛选中；请从列表选择内容。':'换条只更新预览，不上传。');const i=tasks.findIndex(t=>t.id===currentTaskId);root.querySelector('#picker-prev').disabled=busy||i<=0;root.querySelector('#picker-next').disabled=busy||!tasks.length||i===tasks.length-1;}
 root.querySelector('#picker-batch').onchange=e=>{pickerBatch=e.target.value;pickerQuery='';renderPicker();};
 root.querySelector('#picker-search').oninput=e=>{pickerQuery=e.target.value;renderPicker();};
 root.querySelector('#picker-task').onchange=e=>{if(busy)return;const t=catalog?.tasks.find(t=>t.id===e.target.value);if(t)selectTask(t);else{currentTaskId=null;panel();}};
 for(const [id,step] of [['picker-prev',-1],['picker-next',1]])root.querySelector('#'+id).onclick=()=>{if(busy)return;const ts=orderedTasks(),i=ts.findIndex(t=>t.id===currentTaskId);selectTask(ts[i<0?0:i+step]);};
 root.querySelector('#picker-refresh').onclick=async()=>{if(busy)return;try{await loadCatalog();if(host.isConnected)renderPicker();}catch(e){root.querySelector('#picker-status').textContent=e.message;}};
 host.refreshPicker=renderPicker;
 if(catalog)renderPicker();else loadCatalog().then(()=>{if(host.isConnected)renderPicker();}).catch(e=>{if(host.isConnected)root.querySelector('#picker-status').textContent=e.message+'；请保持分发台打开，再点刷新内容。';});
 const status=root.querySelector('#status');const save=root.querySelector('#save');const fillButton=root.querySelector('#fill');
 document.documentElement.append(host);
 const bar=root.querySelector('#panel-bar'),section=root.querySelector('section'),ui=readUI();
 let expandedHeight=Number(ui.height)||650,collapsed=!!ui.collapsed,persistTimer;
 const clamp=()=>{const rect=host.getBoundingClientRect();host.style.right='auto';host.style.left=Math.max(8,Math.min(innerWidth-Math.min(rect.width,innerWidth-16)-8,rect.left))+'px';host.style.top=Math.max(8,Math.min(innerHeight-Math.min(rect.height,innerHeight-16)-8,rect.top))+'px';};
 const persist=()=>{clearTimeout(persistTimer);persistTimer=setTimeout(()=>{if(!host.isConnected)return;const r=host.getBoundingClientRect();if(!collapsed)expandedHeight=section.getBoundingClientRect().height;try{localStorage.setItem(UI_KEY,JSON.stringify({left:r.left,top:r.top,width:section.getBoundingClientRect().width,height:expandedHeight,collapsed}));}catch{}},120);};
 section.style.width=Math.max(280,Math.min(innerWidth-16,Number(ui.width)||350))+'px';section.style.height=Math.max(160,Math.min(innerHeight-16,expandedHeight))+'px';if(Number.isFinite(ui.left)){host.style.left=ui.left+'px';host.style.right='auto';}if(Number.isFinite(ui.top))host.style.top=ui.top+'px';
 const applyCollapse=()=>{root.querySelector('#panel-body').hidden=collapsed;section.style.height=collapsed?'auto':Math.max(160,Math.min(innerHeight-16,expandedHeight))+'px';section.style.minHeight=collapsed?'0':'160px';section.style.resize=collapsed?'none':'both';root.querySelector('#collapse').textContent=collapsed?'展开':'收起';clamp();persist();};applyCollapse();
 bar.onpointerdown=e=>{if(e.target.closest('button'))return;const rect=host.getBoundingClientRect(),dx=e.clientX-rect.left,dy=e.clientY-rect.top;bar.setPointerCapture(e.pointerId);bar.onpointermove=ev=>{host.style.right='auto';host.style.left=ev.clientX-dx+'px';host.style.top=ev.clientY-dy+'px';clamp();};bar.onpointerup=()=>{bar.onpointermove=null;persist();};};
 for(const [id,step] of [['smaller',-80],['larger',80]])root.querySelector('#'+id).onclick=()=>{const r=section.getBoundingClientRect();section.style.width=Math.max(280,Math.min(innerWidth-16,r.width+step))+'px';if(!collapsed){expandedHeight=Math.max(160,Math.min(innerHeight-16,r.height+step));section.style.height=expandedHeight+'px';}clamp();persist();};
 root.querySelector('#collapse').onclick=()=>{if(!collapsed)expandedHeight=section.getBoundingClientRect().height;collapsed=!collapsed;applyCollapse();};
 const resizeObserver=new ResizeObserver(()=>{clamp();persist();});resizeObserver.observe(section);
 const cleanup=new MutationObserver(()=>{if(!host.isConnected){resizeObserver.disconnect();cleanup.disconnect();clearTimeout(persistTimer);}});cleanup.observe(document.documentElement,{childList:true});
 root.querySelector('#sync-title').onclick=async()=>{if(busy||!selected)return;if(boundTaskId!==task.id){status.textContent='请先加载本条内容，或通过仅填写入口确认页面视频是本条内容。';return;}setBusy(true);try{await field('title','fill',{value:task.title});status.textContent='短标题已重新填写并回读：'+task.title;}catch(e){status.textContent='短标题未完成：'+e.message;}finally{setBusy(false);}};

 root.querySelector('#diagnose').onclick=async()=>{
  try{
   const report={version:'0.6.1',frames:await scan(),iframes:[...document.querySelectorAll('iframe')].map(f=>{try{const u=new URL(f.src,location.href);return {host:u.hostname,path:u.pathname};}catch{return {host:'unknown'};}})};
   status.textContent=report.frames.map(f=>'frame '+f.frameId+' '+f.path+' '+JSON.stringify(f.counts||f.error)).join('\n')||'没有frame代理连接，请重新加载扩展并刷新平台';
   const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='视频号页面结构诊断.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }catch(e){status.textContent=e.message;}
 };
 const cover=assets.find(a=>a.id===task.cover_id);if(cover)file(cover).then(f=>{const url=URL.createObjectURL(f),image=root.querySelector('#cover');image.onload=()=>URL.revokeObjectURL(url);image.src=url;image.hidden=false;}).catch(e=>status.textContent=e.message);
 root.querySelector('#upload-cover').onclick=async()=>{
  if(!cover){status.textContent='任务没有指定封面';return;}
  if(boundTaskId!==task.id){status.textContent='请先加载本条内容，或通过仅填写入口确认页面视频是本条内容。';return;}
  if(busy)return;
  setBusy(true);
  try{
   const result=await field('cover','upload',{asset:cover});status.textContent=result.previewReady?'已检测到新的封面预览，请核对并完成平台裁切确认。':'文件已传入：'+(result.reason||'替换结果尚未确认')+'。请核对中间裁切图后点击平台确认。';
  }catch(e){status.textContent='封面暂停：'+e.message+'；可以手动选择任务封面。';}finally{setBusy(false);}
 };
 let uploaded=false;
 const runFill=async(manual)=>{
  if(busy||!selected)return;
  if(task.status==='unknown'&&!confirm('这条内容上传结果不明。请先检查平台没有重复草稿或作品，再继续加载。'))return;
  if(!confirm('向当前视频号填写「'+task.title+'」；目标账号：'+task.account+'。请确认当前账号正确。'))return;
  setBusy(true);fillButton.disabled=true;status.textContent='准备素材…';
  try{
   if(!location.pathname.includes('/post/create'))throw Error('请进入发表视频页面再操作');
   if(task.title.length>16)throw Error('短标题超过16字符，请先在分发台修改');
   if(!manual&&(task.asset_ids.length!==1||!assets.some(a=>a.id===task.asset_ids[0]&&a.kind==='video')))throw Error('本条内容需在分发台选择一个有效视频文件');
   const report=await preflight(manual);
   if(!manual&&report.some(f=>f.counts?.existingVideo>0))throw Error('页面已有视频。为避免把新文案写到旧视频上，请先打开一个空白发表页面；若视频就是这条内容，请用仅填写入口。');
   const binding=await chrome.runtime.sendMessage({type:'observation-bind',task_id:task.id,revision:task.revision,binding_reason:manual?'manual_adoption':'fill_started'});if(!binding?.ok)throw Error('未能关联本次操作：'+(binding?.error||'请刷新扩展后重试'));boundTaskId=task.id;boundTaskTitle=task.title;observation.textContent='当前页面关联：'+task.title+'；页面账号：'+(binding.result?.observed_account||'尚未识别')+'。'+(binding.result?.warning||'');
   if(!manual){
    if(uploaded)throw Error('本面板已提交过视频，请使用仅填写入口');
    uploaded=true;await field('video','upload',{asset:assets.find(a=>a.id===task.asset_ids[0])});
   }
   status.textContent='等待视频预览出现，再同步文案…';
   if(!manual){let ready=false;for(let i=0;i<90;i++){const reports=await scan();if(reports.some(f=>f.counts?.existingVideo===1&&(f.counts?.coverEdit===1||f.counts?.cover===1))&&reports.some(f=>f.counts?.title===1)){ready=true;break;}await new Promise(r=>setTimeout(r,1000));}if(!ready)throw Error('视频尚未显示封面编辑入口，请等待平台上传完成后使用仅填写入口');}
   status.textContent='填写描述与短标题…';
   const tags=String(task.tags||'').trim();const copy=String(task.body||'').trim()+(tags&&!String(task.body||'').includes(tags)?'\n\n'+tags:'');
   const warnings=[];
   let bodyOK=false,titleOK=false;
   try{await field('title','fill',{value:task.title});titleOK=true;}catch(e){warnings.push(e.message);}
   try{await field('body','fill',{value:copy});bodyOK=true;}catch(e){warnings.push(e.message);}
   if(cover){
    status.textContent='等待平台封面编辑入口…';
    try{
     let found=false,alreadyOpen=false;
     for(let i=0;i<30;i++){const reports=await scan();if(reports.reduce((n,f)=>n+(f.counts?.coverEdit||0),0)===1){found=true;break;}if(reports.reduce((n,f)=>n+(f.counts?.cover||0),0)===1){found=true;alreadyOpen=true;break;}await new Promise(r=>setTimeout(r,1000));}
     if(!found)throw Error('封面入口未识别，请打开封面弹窗后点击面板封面按钮');
     if(!alreadyOpen)await field('coverEdit','click');
     const opened=await scan();if(opened.reduce((n,f)=>n+(f.counts?.coverUpload||0),0)===1)await field('coverUpload','click');
     let ready=false;for(let i=0;i<20;i++){const reports=await scan();if(reports.reduce((n,f)=>n+(f.counts?.cover||0),0)===1){ready=true;break;}await new Promise(r=>setTimeout(r,250));}
     if(!ready)throw Error('请在平台打开上传封面选项，再点击面板封面按钮');
     const uploadResult=await field('cover','upload',{asset:cover});
     const reports=await scan();if(uploadResult.previewReady&&reports.reduce((n,f)=>n+(f.counts?.coverConfirm||0),0)===1){await field('coverConfirm','click');warnings.push('已点击封面确认，请核对平台缩略图是否为所选封面');}else warnings.push(uploadResult.previewReady?'已检测到新的封面预览，请在平台核对并确认':'文件已传入，但未检测到新的封面预览，替换结果尚未确认');
    }catch(e){warnings.push('封面：'+e.message);}
   }

   try{await field('label','select');}catch(e){warnings.push('视频标注：'+e.message);}
   if(root.querySelector('#declare-original').checked)try{await field('original','select');}catch(e){warnings.push('声明原创：'+e.message);}
   if(task.options?.collection)try{await field('collection','select',{value:task.options.collection});}catch(e){warnings.push('合集：'+e.message);}
   const scheduled=task.assistScheduled||task.scheduled;
   if(scheduled)try{await field('schedule','schedule',{value:scheduled});}catch(e){warnings.push('定时：'+e.message);}

   try{await field('title','fill',{value:task.title});titleOK=true;}catch(e){titleOK=false;warnings.push(e.message);}
   status.textContent=(warnings.length?'待手动核对：\n'+warnings.join('\n')+'\n':'')+(bodyOK&&titleOK?'描述和短标题已回读确认。':'文案或短标题仍需核对。')+'话题以文本写入，请核对平台是否识别为话题。\n请核对封面裁切、合集、标注和时间，然后保存草稿。';save.disabled=!(bodyOK&&titleOK);
  }catch(e){status.textContent='暂停：'+e.message+(uploaded?'\n已请求视频上传，结果请核对平台，勿重复上传。':'\n本面板尚未提交视频。');}
  finally{setBusy(false);fillButton.disabled=uploaded;}
 };
 fillButton.onclick=()=>runFill(false);
 // Opening or selecting only previews; runFill requires an explicit user click.
 root.querySelector('#fill-only').onclick=()=>{if(busy)return;if(confirm('确认你已在平台选择了本任务的视频？将仅填写，不再次上传。'))runFill(true);};
 save.onclick=async()=>{
  if(busy)return;
  if(!confirm('确认视频上传已完成，封面、话题、描述、短标题和个人观点均已核对？本次仅保存草稿，不公开发布。'))return;
  try{setBusy(true);save.disabled=true;await field('save','click');const recorded=await chrome.runtime.sendMessage({type:'observation-explicit',event_kind:'draft_clicked'});if(!recorded?.ok)observation.textContent='草稿点击已执行，但观察未记录：'+(recorded?.error||'请核对本机连接');status.textContent='已点击保存草稿一次。请到草稿列表重新打开核对；这还不代表保存成功。';}catch(e){status.textContent='暂停：'+e.message;}finally{setBusy(false);}
 };
 }
 chrome.runtime.onMessage.addListener((m,sender,reply)=>{if(m.type==='observation-feedback'){const el=currentHost?.shadowRoot?.querySelector('#page-observation');if(el)el.textContent=[m.observed_account?'页面账号：'+m.observed_account:'账号尚未识别',({schedule_changed:'检测到时间修改',submit_clicked:'检测到点击发布，结果待核对',draft_clicked:'检测到点击保存草稿，结果待核对',result_observed:'检测到平台提示'})[m.event_kind]||'',m.scheduled_text||'',m.result_text||'',m.recorded?'已记录观察（不等于发布成功）':'',m.error?'记录提示：'+m.error:''].filter(Boolean).join(' · ');return;}if(m.type!=='prepare')return;try{if(busy)throw Error('当前操作尚未完成');currentTaskId=m.task.id;dismissed=false;panel(m.task,m.assets,false);reply({ok:true});}catch(e){reply({ok:false,error:e.message});}});
 const ensurePanel=()=>{const path=location.pathname;if(path!==lastPath){lastPath=path;dismissed=false;}if(path.includes('/post/create')&&!dismissed&&!document.querySelector('#desk-channels-assistant')&&!busy)panel();};
 ensurePanel();setInterval(ensurePanel,1200);
})();
